---
name: Feature request / compatibility enhancement
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

<!--- Please, consider to contact us on Discord or IRC before opening an issue. More info and Discord invitation link here: https://github.com/v1s1t0r1sh3r3/airgeddon/wiki/Contact -->
<!--- Did you read the FAQ & Troubleshooting wiki section before doing this? Maybe the answer is there: https://github.com/v1s1t0r1sh3r3/airgeddon/wiki/FAQ%20&%20Troubleshooting -->
<!--- Answer the questions to provide maximum of info -->
<!--- Filling this issue template is mandatory. Otherwise the issue can be directly closed -->
<!--- Write in English only -->
<!--- If additional info is required and requested by airgeddon's staff, you have 7 days to respond, otherwise the issue will be closed -->
<!--- Read the Issue Creation Policy on Contributing section before creating the issue -->

#### Describe the feature or compatibility enhancement and involved versions if apply

<!--- Insert answer here -->

#### What are the benefits of adding this?

<!--- Insert answer here -->
